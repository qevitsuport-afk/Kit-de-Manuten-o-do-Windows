﻿#Requires -Version 5.1
<#
  QEVIT SUPORT - Diagnóstico do Windows 11 (SÓ LEITURA)
  Não altera nem apaga nada. Gera um relatório de texto no Ambiente de Trabalho.
  O relatório não inclui nome do utilizador, nome do computador nem números de série.
#>
$ErrorActionPreference = 'SilentlyContinue'
$pasta = [Environment]::GetFolderPath('Desktop')
if (-not $pasta) { $pasta = $PWD.Path }
$ficheiro = Join-Path $pasta ("QEVIT_Diagnostico_Windows_{0}.txt" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$L = New-Object System.Collections.Generic.List[string]
function Secao([string]$t) { $L.Add(''); $L.Add("=== $t ===") }
function Linha([string]$t) { $L.Add($t) }

$L.Add('QEVIT SUPORT - Relatório de diagnóstico do Windows')
$L.Add('Data: ' + (Get-Date -Format 'dd/MM/yyyy HH:mm'))

Secao 'Sistema'
$os = Get-CimInstance Win32_OperatingSystem
if ($os) {
  Linha ("Sistema: {0}" -f $os.Caption)
  Linha ("Versão / compilação: {0} / {1}" -f $os.Version, $os.BuildNumber)
  $up = (Get-Date) - $os.LastBootUpTime
  Linha ("Tempo desde o último arranque: {0} dias, {1} h, {2} min" -f $up.Days, $up.Hours, $up.Minutes)
  if ($up.Days -ge 7) { Linha 'AVISO: o computador não é reiniciado há 7 dias ou mais. Reinicie para aplicar actualizações.' }
}

Secao 'Processador e memória'
Get-CimInstance Win32_Processor | ForEach-Object { Linha ("CPU: {0} ({1} núcleos)" -f $_.Name.Trim(), $_.NumberOfCores) }
if ($os) {
  $totalGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
  $livreGB = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
  Linha ("RAM: {0} GB no total, {1} GB livres" -f $totalGB, $livreGB)
  if ($totalGB -gt 0 -and ($livreGB / $totalGB) -lt 0.10) { Linha 'AVISO: menos de 10% de RAM livre.' }
}

Secao 'Discos'
Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {
  $tot = [math]::Round($_.Size / 1GB, 1); $liv = [math]::Round($_.FreeSpace / 1GB, 1)
  $pct = if ($_.Size -gt 0) { [math]::Round(100 * $_.FreeSpace / $_.Size, 0) } else { 0 }
  Linha ("{0} {1} GB livres de {2} GB ({3}% livre)" -f $_.DeviceID, $liv, $tot, $pct)
  if ($pct -lt 15) { Linha ("AVISO: {0} com pouco espaço livre." -f $_.DeviceID) }
}
Get-PhysicalDisk | ForEach-Object { Linha ("Disco físico: {0} | {1} | estado: {2}" -f $_.FriendlyName, $_.MediaType, $_.HealthStatus) }

Secao 'Segurança'
$mp = Get-MpComputerStatus
if ($mp) {
  Linha ("Antivírus do Windows activo: {0}" -f $mp.AntivirusEnabled)
  Linha ("Protecção em tempo real: {0}" -f $mp.RealTimeProtectionEnabled)
  Linha ("Última actualização de definições: {0}" -f $mp.AntivirusSignatureLastUpdated)
} else { Linha 'Estado do Windows Defender indisponível (pode haver outro antivírus instalado).' }
Get-NetFirewallProfile | ForEach-Object { Linha ("Firewall {0}: {1}" -f $_.Name, $_.Enabled) }

Secao 'Actualizações'
$wu = Get-Service wuauserv
if ($wu) { Linha ("Serviço Windows Update: {0}" -f $wu.Status) }
$pend = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
        (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
Linha ("Reinício pendente: {0}" -f $(if ($pend) { 'SIM' } else { 'não' }))
Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 5 | ForEach-Object {
  Linha ("Actualização {0} instalada em {1}" -f $_.HotFixID, $_.InstalledOn)
}

Secao 'Desempenho'
Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 5 | ForEach-Object {
  Linha ("{0}: {1} MB" -f $_.ProcessName, [math]::Round($_.WorkingSet64 / 1MB, 0))
}
$arr = @(Get-CimInstance Win32_StartupCommand)
Linha ("Programas que arrancam com o Windows: {0}" -f $arr.Count)
$bat = Get-CimInstance Win32_Battery
if ($bat) { Linha ("Bateria: {0}% de carga" -f $bat.EstimatedChargeRemaining) }

$L | Out-File -FilePath $ficheiro -Encoding UTF8
$L | ForEach-Object { Write-Host $_ }
Write-Host ''
Write-Host "Relatório guardado em: $ficheiro" -ForegroundColor Green
