﻿#Requires -Version 5.1
<#
  QEVIT SUPORT - Reparação opcional do Windows 11 (DISM + SFC)
  Usa apenas ferramentas oficiais da Microsoft. Pede confirmação antes de cada fase.
  Requer privilégios de Administrador.
#>
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
  Write-Host 'Este script precisa de privilégios de Administrador.' -ForegroundColor Yellow
  Write-Host 'Use o ficheiro Executar-Reparacao.bat ou clique com o botão direito no PowerShell e escolha "Executar como administrador".'
  Read-Host 'Prima Enter para sair'
  exit 1
}
$pasta = [Environment]::GetFolderPath('Desktop')
$log = Join-Path $pasta ("QEVIT_Reparacao_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
Start-Transcript -Path $log | Out-Null

Write-Host 'QEVIT SUPORT - Reparação do Windows' -ForegroundColor Cyan
Write-Host 'Recomendado: faça uma cópia de segurança dos seus ficheiros importantes antes de continuar.'
Write-Host 'O processo pode demorar de 10 a 40 minutos. Não desligue o computador.'
$r = Read-Host 'Escreva SIM para continuar'
if ($r -ne 'SIM') { Write-Host 'Cancelado. Nada foi alterado.'; Stop-Transcript | Out-Null; exit 0 }

Write-Host "`n[1/3] A verificar o estado da imagem do Windows (só leitura)..." -ForegroundColor Cyan
DISM /Online /Cleanup-Image /CheckHealth
DISM /Online /Cleanup-Image /ScanHealth

$r2 = Read-Host "`nDeseja executar a reparação da imagem (RestoreHealth, precisa de internet)? Escreva SIM para aceitar"
if ($r2 -eq 'SIM') {
  Write-Host "`n[2/3] A reparar a imagem do Windows..." -ForegroundColor Cyan
  DISM /Online /Cleanup-Image /RestoreHealth
} else { Write-Host '[2/3] Reparação da imagem ignorada.' }

Write-Host "`n[3/3] A verificar ficheiros do sistema (SFC)..." -ForegroundColor Cyan
sfc /scannow

Write-Host "`nConcluído. Registo guardado em: $log" -ForegroundColor Green
Write-Host 'Reinicie o computador para finalizar eventuais reparações.'
Stop-Transcript | Out-Null
Read-Host 'Prima Enter para sair'
