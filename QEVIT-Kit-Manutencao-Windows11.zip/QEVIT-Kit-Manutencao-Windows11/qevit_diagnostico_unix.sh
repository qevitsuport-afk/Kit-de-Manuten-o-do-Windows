#!/usr/bin/env bash
# QEVIT SUPORT - Diagnóstico básico para Linux e macOS (SÓ LEITURA, sem sudo)
# Uso: bash qevit_diagnostico_unix.sh
set -u
dest="$HOME/Desktop"; [ -d "$dest" ] || dest="$PWD"
out="$dest/QEVIT_Diagnostico_$(date +%Y%m%d_%H%M%S).txt"
{
  echo "QEVIT SUPORT - Relatório de diagnóstico ($(uname -s))"
  echo "Data: $(date '+%d/%m/%Y %H:%M')"
  echo; echo "=== Sistema ==="
  uname -srm
  [ -r /etc/os-release ] && grep -E '^PRETTY_NAME=' /etc/os-release | cut -d= -f2 | tr -d '"'
  command -v sw_vers >/dev/null 2>&1 && sw_vers
  echo "Tempo ligado: $(uptime | sed 's/^ *//')"
  echo; echo "=== Memória ==="
  if command -v free >/dev/null 2>&1; then free -h
  elif command -v vm_stat >/dev/null 2>&1; then
    echo "RAM total: $(( $(sysctl -n hw.memsize) / 1073741824 )) GB"; vm_stat | head -5
  else echo "Indisponível."; fi
  echo; echo "=== Discos ==="
  df -h / | tail -n +1
  pct=$(df -P / | awk 'NR==2{gsub("%","",$5); print $5}')
  [ "${pct:-0}" -ge 85 ] && echo "AVISO: disco principal com mais de 85% de ocupação."
  echo; echo "=== 5 processos que mais memória usam ==="
  ps -eo comm,rss 2>/dev/null | sort -k2 -nr | head -5 | awk '{printf "%s: %d MB\n",$1,$2/1024}'
} 2>/dev/null | tee "$out"
echo; echo "Relatório guardado em: $out"
