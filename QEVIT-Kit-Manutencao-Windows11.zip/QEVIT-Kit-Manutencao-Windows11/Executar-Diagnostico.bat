@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0QEVIT-Diagnostico-Windows11.ps1"
pause
