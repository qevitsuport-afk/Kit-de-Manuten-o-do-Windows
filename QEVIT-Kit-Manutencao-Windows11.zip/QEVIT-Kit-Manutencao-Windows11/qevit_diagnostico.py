#!/usr/bin/env python3
"""QEVIT SUPORT - Relatório de diagnóstico multiplataforma (Windows, macOS, Linux).
Só leitura. Usa apenas a biblioteca padrão do Python 3.6+. Não envia dados para a internet.
Opção --rede: testa também a resolução de nomes (DNS)."""
import ctypes, datetime, os, platform, shutil, socket, subprocess, sys

def gb(n): return round(n / 1024 ** 3, 1)

def memoria():
    s = platform.system()
    try:
        if s == "Linux":
            d = {}
            with open("/proc/meminfo") as f:
                for l in f:
                    k, v = l.split(":", 1); d[k] = int(v.split()[0]) * 1024
            return d["MemTotal"], d.get("MemAvailable", d.get("MemFree"))
        if s == "Darwin":
            return int(subprocess.check_output(["sysctl", "-n", "hw.memsize"])), None
        if s == "Windows":
            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("c", ctypes.c_ulong)] + \
                           [(n, ctypes.c_ulonglong) for n in ("tf", "af", "tp", "ap", "tv", "av", "ae")]
            m = MS(); m.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.tf, m.af
    except Exception:
        pass
    return None, None

def uptime():
    s = platform.system()
    try:
        if s == "Linux":
            return float(open("/proc/uptime").read().split()[0])
        if s == "Darwin":
            out = subprocess.check_output(["sysctl", "-n", "kern.boottime"]).decode()
            return datetime.datetime.now().timestamp() - int(out.split("sec =")[1].split(",")[0])
        if s == "Windows":
            return ctypes.windll.kernel32.GetTickCount64() / 1000
    except Exception:
        pass
    return None

def discos():
    if platform.system() == "Windows":
        return [c + ":\\" for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(c + ":\\")]
    return ["/"]

def main():
    L = ["QEVIT SUPORT - Relatório de diagnóstico", "Data: " + datetime.datetime.now().strftime("%d/%m/%Y %H:%M"),
         "", "=== Sistema ===",
         "Sistema: %s %s" % (platform.system(), platform.release()),
         "Arquitectura: " + platform.machine(),
         "Processadores lógicos: %s" % os.cpu_count(), "Python: " + platform.python_version()]
    u = uptime()
    if u is not None:
        d, h = int(u // 86400), int(u % 86400 // 3600)
        L.append("Tempo ligado: %d dias, %d h" % (d, h))
        if d >= 7: L.append("AVISO: sem reiniciar há 7 dias ou mais.")
    t, a = memoria()
    L += ["", "=== Memória ==="]
    if t:
        L.append("RAM total: %s GB" % gb(t))
        if a:
            L.append("RAM disponível: %s GB" % gb(a))
            if a / t < 0.10: L.append("AVISO: menos de 10% de RAM disponível.")
    else:
        L.append("Indisponível neste sistema.")
    L += ["", "=== Discos ==="]
    for p in discos():
        try:
            x = shutil.disk_usage(p); pct = round(100 * x.free / x.total)
            L.append("%s %s GB livres de %s GB (%d%% livre)" % (p, gb(x.free), gb(x.total), pct))
            if pct < 15: L.append("AVISO: %s com pouco espaço livre." % p)
        except Exception:
            L.append("%s: não foi possível ler." % p)
    if "--rede" in sys.argv:
        L += ["", "=== Rede ==="]
        try:
            socket.setdefaulttimeout(4); socket.gethostbyname("example.com")
            L.append("Resolução de nomes (DNS): OK")
        except Exception:
            L.append("Resolução de nomes (DNS): FALHOU. Verifique a ligação à internet.")
    txt = "\n".join(L)
    print(txt)
    pasta = os.path.join(os.path.expanduser("~"), "Desktop")
    if not os.path.isdir(pasta): pasta = os.getcwd()
    f = os.path.join(pasta, "QEVIT_Diagnostico_%s.txt" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
    try:
        with open(f, "w", encoding="utf-8") as o: o.write(txt + "\n")
        print("\nRelatório guardado em: " + f)
    except OSError as e:
        print("\nNão foi possível guardar o relatório: %s" % e)

if __name__ == "__main__":
    main()
